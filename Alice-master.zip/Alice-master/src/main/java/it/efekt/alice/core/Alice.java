package it.efekt.alice.core;

import it.efekt.alice.commands.HelpCmd;
import it.efekt.alice.commands.admin.*;
import it.efekt.alice.commands.core.CommandListener;
import it.efekt.alice.commands.core.CommandManager;
import it.efekt.alice.commands.fun.*;
import it.efekt.alice.commands.games.ApexStatsCmd;
import it.efekt.alice.commands.games.GameStatsCmd;
import it.efekt.alice.commands.games.MinecraftStatusCmd;
import it.efekt.alice.commands.nsfw.AnimeCharacterCmd;
import it.efekt.alice.commands.nsfw.HentaiCmd;
import it.efekt.alice.commands.nsfw.NekoCmd;
import it.efekt.alice.commands.util.*;
import it.efekt.alice.commands.voice.*;
import it.efekt.alice.config.Config;
import it.efekt.alice.db.GameStatsManager;
import it.efekt.alice.db.GuildConfigManager;
import it.efekt.alice.db.TextChannelConfigManager;
import it.efekt.alice.db.UserStatsManager;
import it.efekt.alice.lang.LanguageManager;
import it.efekt.alice.listeners.AnalyticsListener;
import it.efekt.alice.listeners.GameListener;
import it.efekt.alice.listeners.MessageListener;
import it.efekt.alice.listeners.ReadyListener;
import it.efekt.alice.modules.AliceAudioManager;
import it.efekt.alice.modules.GuildLogger;
import it.efekt.alice.modules.mentions.Greetings;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.sharding.DefaultShardManagerBuilder;
import net.dv8tion.jda.api.sharding.ShardManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.security.auth.login.LoginException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Alice {
    public final static Logger logger = LoggerFactory.getLogger(Alice.class);
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private ShardManager shardManager;
    private Config config;
    private CommandManager cmdManager;
    private GuildConfigManager guildConfigManager;
    private GuildLogger guildLogger;
    private UserStatsManager userStatsManager;
    private GameStatsManager gameStatsManager;
    private LanguageManager languageManager;
    private AliceAudioManager aliceAudioManager;
    private TextChannelConfigManager textChannelConfigManager;

    public Alice(Config config){
            this.config = config;
            this.init();
    }

    public void registerListeners(){
        this.shardManager.addEventListener(new AnalyticsListener());
        this.shardManager.addEventListener(new Greetings());
        this.shardManager.addEventListener(new MessageListener());
        this.guildLogger = new GuildLogger(this);
        this.shardManager.addEventListener(guildLogger);
        this.shardManager.addEventListener(new GameListener());
        this.shardManager.addEventListener(new CommandListener(this.cmdManager, this));
    }

    public void registerManagers(){
        this.guildConfigManager = new GuildConfigManager();
        this.cmdManager = new CommandManager(this);
        this.userStatsManager = new UserStatsManager();
        this.gameStatsManager = new GameStatsManager();
        this.languageManager = new LanguageManager();
        this.aliceAudioManager = new AliceAudioManager(getConfig());
        this.textChannelConfigManager = new TextChannelConfigManager();
    }

    public void registerCommands(){
        getCmdManager().setExecutor(new PingCmd("ping"));
        getCmdManager().setExecutor(new HelpCmd("help"));
        getCmdManager().setExecutor(new PrefixCmd("prefix"));
        getCmdManager().setExecutor(new TomekCmd("tomek"));
        getCmdManager().setExecutor(new TomaszCmd("tomasz"));
        getCmdManager().setExecutor(new AsunaCmd("asuna"));
        getCmdManager().setExecutor(new NekoCmd("neko"));
        getCmdManager().setExecutor(new KojimaCmd("kojima"));
        getCmdManager().setExecutor(new HentaiCmd("h"));
        getCmdManager().setExecutor(new StopCmd("stop"));
        getCmdManager().setExecutor(new StatusCmd("status"));
        getCmdManager().setExecutor(new HistoryDeletionCmd("clean"));
        getCmdManager().setExecutor(new GuildLoggerCmd("logger"));
        getCmdManager().setExecutor(new UserInfoCmd("info"));
        getCmdManager().setExecutor(new TopCmd("top"));
        getCmdManager().setExecutor(new ApexStatsCmd("apex"));
        getCmdManager().setExecutor(new MinecraftStatusCmd("mc"));
        getCmdManager().setExecutor(new FeaturesCmd("cmd"));
        getCmdManager().setExecutor(new LangCmd("lang"));
        getCmdManager().setExecutor(new RandomWaifuCmd("random-waifu"));
        getCmdManager().setExecutor(new GameStatsCmd("topgames"));
        getCmdManager().setExecutor(new LoliCmd("loli"));
        getCmdManager().setExecutor(new WikiCmd("wiki"));
        getCmdManager().setExecutor(new JoinCmd("join"));
        getCmdManager().setExecutor(new LeaveCmd("leave"));
        getCmdManager().setExecutor(new PlayCmd("play"));
        getCmdManager().setExecutor(new NowPlayingCmd("np"));
        getCmdManager().setExecutor(new PauseCmd("pause"));
        getCmdManager().setExecutor(new CalcCmd("calc"));
        getCmdManager().setExecutor(new RecordCmd("rec"));
        getCmdManager().setExecutor(new ImgOnlyCmd("img-only"));
        getCmdManager().setExecutor(new StatsCmd("stats"));
        getCmdManager().setExecutor(new BlacklistReload("topgames-blacklist"));
        getCmdManager().setExecutor(new ServersCmd("servers"));
        getCmdManager().setExecutor(new PlayAgainCmd("playa"));
        getCmdManager().setExecutor(new ReplyCmd("reply"));
        getCmdManager().setExecutor(new TimezoneCmd("timezone"));
        getCmdManager().setExecutor(new AnimeCharacterCmd("a"));
        getCmdManager().setExecutor(new VoteCmd("vote"));
        getCmdManager().setExecutor(new SkipCmd("skip"));
        getCmdManager().setExecutor(new ChooseCommand("choose"));
        getCmdManager().setExecutor(new OptCommand("opt"));
    }

    public void startSchedulers(){
        this.scheduler.scheduleAtFixedRate(new BotStatusRefresher(this), 10, 60, TimeUnit.SECONDS);
    }

    public ShardManager getShardManager(){
        return this.shardManager;
    }

    public Config getConfig(){
        return this.config;
    }

    public CommandManager getCmdManager(){
        return this.cmdManager;
    }

    public GuildConfigManager getGuildConfigManager(){
        return this.guildConfigManager;
    }

    public GuildLogger getGuildLogger(){
        return this.guildLogger;
    }

    public UserStatsManager getUserStatsManager() {
        return this.userStatsManager;
    }

    public GameStatsManager getGameStatsManager(){
        return this.gameStatsManager;
    }

    public LanguageManager getLanguageManager() {
        return languageManager;
    }

    public AliceAudioManager getAliceAudioManager() {
        return aliceAudioManager;
    }

    public TextChannelConfigManager getTextChannelConfigManager() {
        return textChannelConfigManager;
    }

    public void setActivity(Activity activity){
        for (JDA jda : getShardManager().getShards()){
            jda.getPresence().setActivity(activity);
        }
    }

    private void init(){
        Runtime.getRuntime().addShutdownHook(new ShutdownThread(this));
        try {
            DefaultShardManagerBuilder builder = new DefaultShardManagerBuilder();
                builder.setToken(this.getConfig().getToken());
                builder.setShardsTotal(getConfig().getShardsTotal());
                builder.setActivity(Activity.playing("breaking the seal of the right eye..."));
                builder.addEventListeners(new ReadyListener());
                this.shardManager = builder.build();
        } catch (LoginException e) {
            e.printStackTrace();
        }
    }
}


