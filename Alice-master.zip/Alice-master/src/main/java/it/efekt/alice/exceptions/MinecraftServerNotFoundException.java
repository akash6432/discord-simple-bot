package it.efekt.alice.exceptions;

public class MinecraftServerNotFoundException extends Exception {
    public MinecraftServerNotFoundException(String message){
        super(message);
    }
}
