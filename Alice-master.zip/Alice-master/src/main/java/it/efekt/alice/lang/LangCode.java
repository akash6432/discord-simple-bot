package it.efekt.alice.lang;

public enum LangCode {
    en_US,
    pl_PL
}
